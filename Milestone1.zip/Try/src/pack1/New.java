package pack1;

import java.util.HashMap;

class New {
    private String username;
    private String password;
    private String role;
    private boolean isLoggedIn = false;

    private static HashMap<String, String[]> users = new HashMap<>();

    static {
        users.put("instructorOmar", new String[]{"instPassword123", "Course Instructor"});
        users.put("taJohn", new String[]{"taPassword456", "TA"});
        users.put("studentOmar", new String[]{"studentPass789", "Student"});
        users.put("admissionLily", new String[]{"adminPass001", "Admission Staff"});
    }

    public New(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public boolean login() {
        if (users.containsKey(username)) {
            String[] credentials = users.get(username);
            if (credentials[0].equals(password)) {
                this.role = credentials[1];
                this.isLoggedIn = true;
                displayAllowedProcedures();
                return true;
            } else {
                System.out.println("Authentication failed: Incorrect password.");
            }
        } else {
            System.out.println("Authentication failed: Username not found.");
        }
        return false;
    }

    private void displayAllowedProcedures() {
        System.out.println("Login successful! Role: " + this.role);
        System.out.println("Allowed Procedures:");
        switch (this.role) {
            case "Course Instructor":
                System.out.println("- postLectures()");
                System.out.println("- sendEmails()");
                System.out.println("- editGrades()");
                System.out.println("- createAssignment()");
                break;
            case "TA":
                System.out.println("- editGrades()");
                System.out.println("- checkAssignmentSubmission()");
                System.out.println("- sendEmails()");
                break;
            case "Student":
                System.out.println("- checkGrades()");
                System.out.println("- checkAttendance()");
                System.out.println("- checkSchedule()");
                break;
            case "Admission Staff":
                System.out.println("- approveApplication()");
                System.out.println("- rejectApplication()");
                System.out.println("- sendEmails()");
                break;
        }
    }

    private boolean hasAccess(String requiredRole) {
        if (!isLoggedIn) {
            System.out.println("Access Denied: You are not logged in.");
            return false;
        }
        if (this.role.equals(requiredRole)) {
            return true;
        } else {
            return false;
        }
    }

    public void postLectures() {
        if (hasAccess("Course Instructor")) {
            System.out.println("Access Allowed: Posting Lectures.");
        } else {
            System.out.println("Access Denied: You do not have permission to post lectures.");
        }
    }

    public void sendEmails() {
        if (hasAccess("Course Instructor") || hasAccess("TA") || hasAccess("Admission Staff")) {
            System.out.println("Access Allowed: Sending Emails.");
        } else {
            System.out.println("Access Denied: You do not have permission to send emails.");
        }
    }

    public void editGrades() {
        if (hasAccess("Course Instructor") || hasAccess("TA")) {
            System.out.println("Access Allowed: Editing Grades.");
        } else {
            System.out.println("Access Denied: You do not have permission to edit grades.");
        }
    }

    public void checkGrades() {
        if (hasAccess("Student")) {
            System.out.println("Access Allowed: Checking Grades.");
        } else {
            System.out.println("Access Denied: You do not have permission to check grades.");
        }
    }

    public void checkAttendance() {
        if (hasAccess("Student")) {
            System.out.println("Access Allowed: Checking Attendance.");
        } else {
            System.out.println("Access Denied: You do not have permission to check attendance.");
        }
    }

    public void checkAssignmentSubmission() {
        if (hasAccess("TA")) {
            System.out.println("Access Allowed: Checking Assignment Submissions.");
        } else {
            System.out.println("Access Denied: You do not have permission to check assignment submissions.");
        }
    }

    public void checkSchedule() {
        if (hasAccess("Student")) {
            System.out.println("Access Allowed: Checking Schedule.");
        } else {
            System.out.println("Access Denied: You do not have permission to check the schedule.");
        }
    }

    public void approveApplication() {
        if (hasAccess("Admission Staff")) {
            System.out.println("Access Allowed: Approving Application.");
        } else {
            System.out.println("Access Denied: You do not have permission to approve applications.");
        }
    }

    public void rejectApplication() {
        if (hasAccess("Admission Staff")) {
            System.out.println("Access Allowed: Rejecting Application.");
        } else {
            System.out.println("Access Denied: You do not have permission to reject applications.");
        }
    }

    public void createAssignment() {
        if (hasAccess("Course Instructor")) {
            System.out.println("Access Allowed: Creating Assignment.");
        } else {
            System.out.println("Access Denied: You do not have permission to create assignments.");
        }
    }

    public static void main(String[] args) {
    	
    	New student = new New("studentOmar", "studentPass789");
        student.login();  
        student.checkGrades(); //  check grades
        student.checkAssignmentSubmission();
        student.checkAttendance(); // Check attendance (access allowed for Student)
    	
    	
    	
    /*	New ta = new New("taJohn", "taPassword456");
        ta.login();
        ta.editGrades();
        ta.checkAssignmentSubmission();
        ta.postLectures();  // Access denied because TA doesn't have access to post lectures
        ta.checkAttendance();  // */
    	
    	/*New inst = new New("instructorOmar", "instPassword123");
    	inst.login();
    	inst.postLectures();
    	inst.sendEmails();
    	inst.editGrades();
    	inst.createAssignment();
    	inst.checkAssignmentSubmission();
    	inst.checkGrades();*/
    	
    	/*New admin = new New("admissionLily", "adminPass001");
    	admin.login();
    	admin.approveApplication();
    	admin.rejectApplication();
    	admin.sendEmails();
    	admin.checkAttendance();
    	admin.checkAssignmentSubmission();
    	admin.createAssignment();*/
    	
    }
}

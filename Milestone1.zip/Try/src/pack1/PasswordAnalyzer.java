package pack1;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PasswordAnalyzer {

    public static String analyzePasswordStrength(String password) {
        
        Pattern upperCasePattern = Pattern.compile("[A-Z]");
        Pattern lowerCasePattern = Pattern.compile("[a-z]");
        Pattern digitPattern = Pattern.compile("\\d");
        Pattern specialCharPattern = Pattern.compile("[^a-zA-Z0-9\\s]");  
        Pattern spacePattern = Pattern.compile("\\s");  

        
        if (containsPattern(spacePattern, password)) {
            return "Spaces are not allowed in the password.";
        }

       
        if (password.length() < 12 || password.length() > 16) {
            return "Password must be between 12 to 16 characters long.";
        }

       
        int metCriteria = 0;
        StringBuilder feedback = new StringBuilder();

        
        if (containsPattern(upperCasePattern, password)) {
            metCriteria++;
        } else {
            feedback.append("Include at least 1 uppercase letter.\n");
        }

      
        if (containsPattern(lowerCasePattern, password)) {
            metCriteria++;
        } else {
            feedback.append("Include at least 1 lowercase letter.\n");
        }

        
        if (containsPattern(digitPattern, password)) {
            metCriteria++;
        } else {
            feedback.append("Include at least 1 digit.\n");
        }

       
        if (containsPattern(specialCharPattern, password)) {
            metCriteria++;
        } else {
            feedback.append("Include at least 1 special character.\n");
        }

        
        if (metCriteria == 4) {
            return "Strong password!";
        } else if (metCriteria == 3) {
            return "Moderate password!";
        } else {
            return "Weak password!\n" + feedback.toString();
        }
    }

   
    private static boolean containsPattern(Pattern pattern, String password) {
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }

    public static void main(String[] args) {
        String password = "erfnek123456U+";  // Test password (change for testing)
        String result = analyzePasswordStrength(password);
        System.out.println(result);
    }
}
